package linex.android.bloodbank2.activities


import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.navigation.NavigationView
import linex.android.bloodbank2.fragment.ProfileFragment
import linex.android.bloodbank2.R
import linex.android.bloodbank2.fragment.DonnerFragment


class UsersListActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {


    private lateinit var drawableLayout: DrawerLayout
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ContextCompat.getColor(applicationContext, R.color.transparent)
        setContentView(R.layout.activity_users_list)



        drawableLayout = findViewById(R.id.drawableLayout)
        actionBarDrawerToggle =
            ActionBarDrawerToggle(this, drawableLayout, R.string.nav_open, R.string.nav_close)

        drawableLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportActionBar!!.title = "Dashboard"

        val navigationView = findViewById<View>(R.id.navBar) as NavigationView
        navigationView.setNavigationItemSelectedListener(this)

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.mainFrame, DonnerFragment()).commit()

    }

    override fun onBackPressed() {
        val drawerLayout = findViewById<View>(R.id.drawableLayout) as DrawerLayout
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START)
        }else{
            super.onBackPressed()
        }

    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            else -> super.onOptionsItemSelected(item)
        }
    }





    override fun onNavigationItemSelected(item: MenuItem): Boolean {
            val id: Int = item.itemId
            val fragment: Fragment


        when (id) {
            R.id.profile -> {
                fragment = ProfileFragment()
                val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                ft.replace(R.id.mainFrame, fragment, ProfileFragment::class.java.simpleName)
                ft.commit()
            }
            R.id.donor -> {
                fragment = DonnerFragment()
                val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                ft.replace(R.id.mainFrame, fragment)
                ft.commit()
            }
            R.id.logout -> {
                intent = Intent(this@UsersListActivity, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
            val drawer = findViewById<View>(R.id.drawableLayout) as DrawerLayout
            drawer.closeDrawer(GravityCompat.START)
            return true
        }

}











