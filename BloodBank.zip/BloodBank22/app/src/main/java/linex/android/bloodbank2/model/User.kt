package linex.android.bloodbank2.model

data class User(val id: Int = -1,
val name: String, val email: String,
val password: String)
